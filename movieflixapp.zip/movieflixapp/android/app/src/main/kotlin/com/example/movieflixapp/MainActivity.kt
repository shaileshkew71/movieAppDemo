package com.example.movieflixapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
