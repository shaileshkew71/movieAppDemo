import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:movieflixapp/Models/TopRatedModel.dart';

import '../Controllers/TopRatedController.dart';

class TopRatedDescriptionPage extends StatefulWidget {
  final Result nowlist;
  const TopRatedDescriptionPage({Key? key, required this.nowlist}) : super(key: key);

  @override
  State<TopRatedDescriptionPage> createState() => _TopRatedDescriptionPageState();
}

class _TopRatedDescriptionPageState extends State<TopRatedDescriptionPage> {
  TopRatedController controller = Get.find();

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: Stack(
        children: [
          Positioned(
              top: 0,
              bottom: 0,
              left: 0,
              right: 0,
              child: Image.network(
                'https://image.tmdb.org/t/p/w342' + widget.nowlist.posterPath,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                      color: Colors.amber,
                      alignment: Alignment.center,
                      child: Icon(Icons.error,
                        color: Colors.red,
                      ));
                },

                loadingBuilder: (BuildContext context, Widget child,
                    ImageChunkEvent? loadingProgress) {
                  if (loadingProgress == null) {
                    return child;
                  }
                  return Center(
                    child: CircularProgressIndicator(
                      value: loadingProgress.expectedTotalBytes != null
                          ? loadingProgress.cumulativeBytesLoaded /
                              loadingProgress.expectedTotalBytes!
                          : null,
                    ),
                  );
                },
              )),
          Positioned(
            left: 0,
              right: 0,
              bottom: 10,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: SingleChildScrollView(
                  child: Container(
                   // color: Colors.black,
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.9),
                        border: Border.all(
                          color: Colors.black.withOpacity(0.9),
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(05))
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(widget.nowlist.title,
                            textAlign: TextAlign.start,
                            style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 18.0),),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(controller.ConvertDate(widget.nowlist.releaseDate),
                            textAlign: TextAlign.start,
                            style: TextStyle(color: Colors.white,fontSize: 12.0),),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                children: [
                                  Icon(Icons.movie,color: Colors.white,),
                                  Text(widget.nowlist.voteAverage.toString()+"%",
                                      textAlign: TextAlign.start,
                                      style: TextStyle(color: Colors.white,fontSize: 14.0))
                                ],
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                children: [
                                  Icon(Icons.insert_chart,color: Colors.white,),
                                  Text(widget.nowlist.popularity.toString(),
                                      textAlign: TextAlign.start,
                                      style: TextStyle(color: Colors.white,fontSize: 14.0))
                                ],
                              ),
                            ),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(widget.nowlist.overview,
                              maxLines: 5,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  color: Colors.white)),
                        )
                      ],
                    ),
                  ),
                ),
              )),

        ],
      ),
    );
  }
}
