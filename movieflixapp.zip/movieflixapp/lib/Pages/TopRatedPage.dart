import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:movieflixapp/Controllers/TopRatedController.dart';
import 'package:swipe_refresh/swipe_refresh.dart';

import '../Common/function.dart';
import 'TopRatedDescriptionPage.dart';
import 'TopRatedDescriptionPage.dart';

class TopRatedPage extends StatefulWidget {
  const TopRatedPage({Key? key}) : super(key: key);

  @override
  _TopRatedPageState createState() => _TopRatedPageState();
}

class _TopRatedPageState extends State<TopRatedPage> {
  TopRatedController controller = Get.find();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).primaryColor,
        title: CupertinoSearchTextField(
          style: TextStyle(
            color: Colors.black,
          ),
          backgroundColor: Colors.white,
          onChanged: (String value) {
            searchBook(value);
          },
          onSubmitted: (String value) {
            searchBook(value);
          },
        ),
      ),
      body: controller.nowlist.isNotEmpty
          ? SwipeRefresh.builder(
              stateStream: controller.stream,
              onRefresh: () {
                setState(() {
                  controller.refreshpage();
                });
              },
              itemCount: controller.nowlist.length,
              itemBuilder: (context, position) {
                return Dismissible(
                    direction: DismissDirection.endToStart,
                    background: Container(
                      color: Colors.red,
                      alignment: Alignment.centerRight,
                      padding: EdgeInsets.symmetric(horizontal: 10.0),
                      child: Icon(Icons.delete_forever),
                    ),
                    key: UniqueKey(),
                    onDismissed: (DismissDirection direction) async {},
                    child: new GestureDetector(
                        onTap: () {},
                        child: ListTile(
                          onTap: () {
                            Get.to(TopRatedDescriptionPage(
                                nowlist: controller.nowlist[position]!));
                          },
                          leading: Image.network(
                            'https://image.tmdb.org/t/p/w342' +
                                controller.nowlist[position].posterPath,
                            fit: BoxFit.fill,
                            width: 100,
                            height: 400,
                            errorBuilder: (context, error, stackTrace) {
                              return Container(
                                  color: Colors.amber,
                                  alignment: Alignment.center,
                                  child: Icon(
                                    Icons.error,
                                    color: Colors.red,
                                  ));
                            },
                            loadingBuilder: (BuildContext context, Widget child,
                                ImageChunkEvent? loadingProgress) {
                              if (loadingProgress == null) {
                                return child;
                              }
                              return Center(
                                child: CircularProgressIndicator(
                                  value: loadingProgress.expectedTotalBytes !=
                                          null
                                      ? loadingProgress.cumulativeBytesLoaded /
                                          loadingProgress.expectedTotalBytes!
                                      : null,
                                ),
                              );
                            },
                          ),
                          title: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(
                              controller.nowlist[position].title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black),
                            ),
                          ),
                          subtitle: Text(controller.nowlist[position].overview,
                              maxLines: 5,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: Colors.black)),
                        )));
              })
          : Center(
              child: TextButton(
                style: ButtonStyle(
                    elevation: MaterialStateProperty.all(8.0),
                    backgroundColor: MaterialStateProperty.all(
                        Theme.of(context).primaryColor)),
                onPressed: () {
                  setState(() {
                    controller.refreshpage();
                  });
                },
                child: Text(
                  "Press here to refresh page",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
    );
  }

  @override
  void initState() {
    setState(() {
      controller.refreshpage();
    });

    super.initState();
  }

  void searchBook(String query) {
    if (query.length == 0) {
      setState(() {
        controller.refreshpage();
      });
    } else {
      setState(() {
        controller.Search(query);
      });
    }
  }
}
