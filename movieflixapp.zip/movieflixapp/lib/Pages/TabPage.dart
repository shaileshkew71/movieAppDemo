import 'package:flutter/material.dart';
import 'package:movieflixapp/Pages/NowPlayingPage.dart';
import 'package:movieflixapp/Pages/TopRatedPage.dart';

class TabPage extends StatefulWidget {
  const TabPage({Key? key}) : super(key: key);

  @override
  _TabPageState createState() => _TabPageState();
}

class _TabPageState extends State<TabPage> {
  int _currentIndex = 0;
  static const List<Widget> _widgetOptions = <Widget>[
    NowPlayingPage(),
    TopRatedPage(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: _widgetOptions.elementAt(_currentIndex),
      ),
      backgroundColor: Theme.of(context).primaryColor,
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _currentIndex,
        onTap: _onItemTapped,
        backgroundColor: Theme.of(context).primaryColor,
        selectedItemColor: Colors.black,
        unselectedItemColor: Colors.grey[700],
        selectedLabelStyle: TextStyle(color: Colors.black),
        unselectedLabelStyle: TextStyle(color: Colors.grey[700]),
        items: [
          BottomNavigationBarItem(
            label: 'Now Playing',
            icon: Icon(Icons.movie_filter_outlined),
          ),
          BottomNavigationBarItem(
            label: 'Top Rated',
            icon: Icon(Icons.star_border_outlined),
          ),
        ],
      ),
    );
  }
}
