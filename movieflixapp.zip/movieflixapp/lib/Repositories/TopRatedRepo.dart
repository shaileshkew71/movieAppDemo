import 'dart:convert';

import 'package:movieflixapp/Common/function.dart';
import 'package:movieflixapp/Models/TopRatedModel.dart';

class TopRatedRepo {
  static Future<List<Result>> getResultList() async {
    try {
      var response = await dio.get("/top_rated?api_key=a07e22bc18f5cb106bfe4cc1f83ad8ed");
      printLog(title: "Response-", message: response.data.toString());
      if (response.statusCode == 200) {
        return TopRatedModel.fromJson(jsonDecode(response.data)).results;
      } else {
        return [];
      }
    } catch (e) {
      showMessage(message: "Error 0XXX01 Occurred"+"\n"+" Tap To Dismiss");
      printLog(title: "Api Error", message: e.toString());
      return [];
    }
  }
}
