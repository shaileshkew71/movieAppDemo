import 'dart:developer';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

Dio dio = Dio();

initialiseApiService() {
  BaseOptions options = BaseOptions(
    baseUrl: "https://api.themoviedb.org/3/movie",
    headers: {'Content-Type': 'text/plain'},
    responseType: ResponseType.plain,
  );
  dio = Dio(options);
}

printLog({required String title, required String message}) {
  log('$title:$message');
}

showMessage({required String message}) {
  Get.defaultDialog(title: "Alert", middleText: message);
}

String apikey = "a07e22bc18f5cb106bfe4cc1f83ad8ed";

Future<String> checkNetWorkConnection() async {
  var connectivityResult = await (Connectivity().checkConnectivity());
  if (connectivityResult == ConnectivityResult.mobile ||
      connectivityResult == ConnectivityResult.wifi) {
    initialiseApiService();
    return "Connected";
  } else {
    showMessage(message: "Please Enable Mobile Data or Connect to a Wifi");
    return "Not Connected";
  }
}
Widget LoadingWidget(){
  return Container(
    color: Colors.black,
    height: 200,
    width: 200,
    child: Center(
      child: CircularProgressIndicator(),
    ),
  );
}
