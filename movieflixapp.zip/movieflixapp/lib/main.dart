import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:movieflixapp/Controllers/NowPlayingController.dart';
import 'package:movieflixapp/Controllers/TopRatedController.dart';
import 'package:movieflixapp/Pages/TabPage.dart';

setStatusBarColor() {
  SystemChrome.setSystemUIOverlayStyle( SystemUiOverlayStyle(
      systemNavigationBarColor:  Colors.amber[800],
      statusBarColor: Colors.amber[800],
      statusBarIconBrightness: Brightness.dark));
}
void main() {
  runApp(const MyApp());
  setStatusBarColor();
  Get.put(NowPlayingController());
  Get.put(TopRatedController());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
      primaryColor: Colors.amber[800],
        iconTheme: IconThemeData(
          color: Colors.black
        )
      ),
      home: const TabPage(),
      builder: EasyLoading.init(),
    );
  }
}
