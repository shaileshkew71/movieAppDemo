import 'dart:async';

import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:movieflixapp/Common/function.dart';
import 'package:movieflixapp/Models/TopRatedModel.dart';
import 'package:movieflixapp/Repositories/TopRatedRepo.dart';
import 'package:swipe_refresh/swipe_refresh.dart';

class TopRatedController extends GetxController {
  List<Result> nowlist = [];
  final _controller = StreamController<SwipeRefreshState>.broadcast();

  Stream<SwipeRefreshState> get stream => _controller.stream;

  Future<void> refreshpage() async {
    await Future<void>.delayed(const Duration(seconds: 3));
    // when all needed is done change state
    checkNetCon();
    _controller.sink.add(SwipeRefreshState.hidden);
  }

  checkNetCon() async {
    EasyLoading.show(status: "Loading", indicator: LoadingWidget());
    await checkNetWorkConnection().then((value) => {
          if (value == "Connected") {callNowApi()}
        });
  }

  callNowApi() async {
    try {
      nowlist.clear();
      await TopRatedRepo.getResultList().then((value) => {
            if (value.isNotEmpty) {EasyLoading.dismiss(), nowlist = value}
          });
    } catch (e) {
      EasyLoading.dismiss();
      showMessage(message: "Error 0XXX02 Occurred" + "\n" + " Tap To Dismiss");
      printLog(title: "Top Rated Controller Error", message: e.toString());
    }
  }

  String ConvertDate(DateTime dateTime) {
    String formattedDate = DateFormat('MMM-dd-yyyy').format(dateTime);
    return formattedDate;
  }

  Search(String query) {
    nowlist = nowlist.where((Result) {
      var title = Result.title.toLowerCase();
      return title.contains(query);
    }).toList();
  }
}
